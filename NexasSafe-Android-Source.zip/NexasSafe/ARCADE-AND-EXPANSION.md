# Nexas Safe 3.6 — Arcade Plus

The Games area now contains nine short mini-games and one breathing reset:
- Pattern Memory
- Reaction Tap
- Tile Match (eight matching pairs)
- Odd One Out (five visual rounds)
- Mental Maths
- Number Sequence
- Word Scramble
- Quick Quiz (offline general knowledge)
- Color Match
- Breathing Reset

The arcade screen has a pastel hero panel, animated emblem, local points summary, grouped game categories, premium icon tiles, clearer game descriptions and touch feedback. Scores and completed-game totals remain local to the device. No online leaderboard, advertising, or social comparison is included.

Version: 3.6.0. This is source code, not a verified APK. Run the GitHub Actions Android build and test on a physical device before distribution.
