# Nexas Safe 3.7 — Premium Arcade Edition

## Arcade expansion
- Expanded the Games area to nine mini-games plus a guided breathing reset.
- Added Tile Match, Odd One Out, Number Sequence, Quick Quiz and Color Match.
- Added a premium arcade hero panel with animated emblem and local totals.
- Reworked game cards with icon tiles, category labels, clearer descriptions and animated entrances.
- Added a locally stored completed-game count and earned-point tally.
- Kept games offline-first, optional and free of public leaderboards or pressure-based competition.

## Build
- Android version name: 3.7.0
- Android version code: 12
- Requires Android SDK platform 35 and Java 17 for the supplied workflow.

Source checks performed: archive test and Java parser-level syntax check. A full Android Gradle compilation and device test are still required in GitHub Actions.
