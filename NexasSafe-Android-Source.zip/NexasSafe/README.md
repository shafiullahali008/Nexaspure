# Nexas Safe 3.7 — Premium Arcade Edition

**Tagline:** Stay Pure. Make room for what matters.

Nexas Safe is an Android digital-wellbeing and focus project. This edition replaces the previous long single-page dashboard with separate screens and adds a first-launch welcome flow.

## App structure

- **Welcome flow:** three short onboarding stages with a custom animated, layered 3D-style orbit illustration.
- **Home:** clear status overview and quick links to the app's main areas.
- **Focus Studio:** circular progress countdown, session presets, custom duration, selected-app controls and Strict Mode.
- **Smart Protection:** optional on-device image checks, user-approved screen capture, keyword settings and a personal block screen.
- **Progress:** daily intention, goal progress, streaks, local points and activity totals.
- **About:** creator profile, local portrait, interests, project background and Instagram contact.
- **Settings:** daily reminder, permission status and privacy/recovery notes.

## Build

The project uses Java 17, Android Gradle Plugin 8.7.3, Gradle 8.9 and Android SDK 35. From the project root:

```bash
./gradlew --no-daemon clean assembleDebug
```

The debug APK is created under:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## GitHub Actions build

If you upload this project as a ZIP into a new, otherwise-empty GitHub repository, also create the workflow file at `.github/workflows/android.yml` in the repository root. Use the separate `android.yml` file supplied with this release. The workflow extracts `NexasSafe-Android-Source.zip`, locates the Gradle wrapper, builds the debug APK and uploads it as an artifact.

## Important platform limits

- Android does not let an ordinary app inspect every screen or decode every video frame in every other app. Protection depends on the Android permissions granted, the APIs exposed by the other app, and the enabled feature.
- Keyword matching is best-effort and may miss content or produce false positives.
- The image classifier is a lightweight on-device classifier, not a guarantee of detecting all unsafe content.
- Screen capture requires the user's Android consent and an ongoing foreground notification.
- Strict Mode adds an intentional early-exit pause, but Android Settings and the user's recovery and uninstall controls remain available.
- This project has not been tested on every device or Android skin. Verify permissions, battery use, accessibility behaviour and timer recovery on the target phone before relying on it.

## Data and privacy

Profile content, preferences, goals and timer state are stored locally by the app. The bundled creator photograph is an app resource; it is not uploaded by Nexas Safe. The Instagram action opens the public profile link `https://www.instagram.com/shafi.viii_/`.

## Version

- Version name: `3.7.0`
- Version code: `12`


## Arcade Plus

The Games section includes nine short offline mini-games: Pattern Memory, Reaction Tap, Tile Match, Odd One Out, Mental Maths, Number Sequence, Word Scramble, Quick Quiz and Color Match, plus a guided Breathing Reset. The arcade landing page uses a pastel feature panel, animated emblem, local completion and points summary, and grouped game cards. Scores and point totals remain on-device.
