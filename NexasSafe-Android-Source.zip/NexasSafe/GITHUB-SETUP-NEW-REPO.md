# Build Nexas Safe 3.7 in GitHub Actions

1. Create a repository or use an existing one with a `main` branch.
2. Upload `NexasSafe-Android-Source.zip` to the repository root.
3. Create `.github/workflows/android.yml` in the repository root.
4. Paste the separate `android.yml` workflow supplied with this release and commit it.
5. Open Actions, choose **Nexas Safe Android Build**, then run the workflow if it has not started automatically.
6. On success, download the `NexasSafe-debug-APK` artifact and extract the APK.

The archive is source code. A successful GitHub Actions build is required to create the APK.
