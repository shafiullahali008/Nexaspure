# Nexas Safe 3.4 — GitHub import

This source archive contains a top-level `NexasSafe/` Android project folder. The updated interface is split into separate Home, Focus, Protection, Progress, About and Settings pages. A three-stage animated welcome flow appears the first time the app is opened.

## New repository setup

1. Create a GitHub repository named `nexas-safe-android` on branch `main`.
2. Upload `NexasSafe-Android-Source.zip` to the repository root and commit it.
3. Create `.github/workflows/android.yml` in the repository root.
4. Paste the separately supplied `android.yml` workflow file and commit it.
5. Open **Actions → Nexas Safe Android Build**. Run it manually if it did not start automatically.
6. When the workflow succeeds, download the `NexasSafe-debug-APK` artifact ZIP and extract `NexasSafe-debug.apk`.

GitHub does not activate a workflow buried inside an uploaded ZIP. The workflow therefore belongs in the repository root as a separate committed file. It extracts this archive and locates `NexasSafe/gradlew` automatically.

## Build configuration

- Java 17
- Android Gradle Plugin 8.7.3
- Gradle 8.9 (bootstrapped by the included wrapper script)
- Android compile SDK 35
- Version name 3.4.0 / version code 9

## Verification

The Android XML files were parsed and Java source syntax was checked. A full Android Gradle build and device-level test could not be run in this environment because the Android SDK is not installed. GitHub Actions must complete successfully before the APK is considered built.
